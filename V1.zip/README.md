# Caraffini CRM
Siga o README no Chat para subir no GitHub, criar Supabase, conectar Vercel e usar o parser de PDF.
